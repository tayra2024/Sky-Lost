import { Component } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ObjetoService } from '../../../core/services/objeto.service';
import { Objeto } from '../../../core/models/objeto.model';

@Component({
  selector: 'app-buscar',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe, RouterLink],
  templateUrl: './buscar.component.html'
})
export class BuscarComponent {
  nombre = '';
  ubicacion = '';
  resultados: Objeto[] = [];
  buscado = false;
  loading = false;
  error = '';

  constructor(private objetoSvc: ObjetoService) {}

  buscar(): void {
    this.loading = true;
    this.buscado = false;
    this.objetoSvc.buscar(this.nombre, this.ubicacion).subscribe({
      next: data => { this.resultados = data; this.buscado = true; this.loading = false; },
      error: () => { this.error = 'Error al buscar.'; this.loading = false; }
    });
  }

  limpiar(): void {
    this.nombre = '';
    this.ubicacion = '';
    this.resultados = [];
    this.buscado = false;
  }
}
