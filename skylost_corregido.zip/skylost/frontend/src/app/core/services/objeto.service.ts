import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Objeto, ObjetoRequest, DevolucionRequest } from '../models/objeto.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ObjetoService {

  private apiUrl = environment.apiUrl + '/objetos';

  constructor(private http: HttpClient) {}

  listar(): Observable<Objeto[]> {
    return this.http.get<Objeto[]>(this.apiUrl);
  }

  obtenerPorId(id: number): Observable<Objeto> {
    return this.http.get<Objeto>(this.apiUrl + '/' + id);
  }

  registrar(dto: ObjetoRequest): Observable<Objeto> {
    return this.http.post<Objeto>(this.apiUrl, dto);
  }

  actualizar(id: number, dto: ObjetoRequest): Observable<Objeto> {
    return this.http.put<Objeto>(this.apiUrl + '/' + id, dto);
  }

  eliminar(id: number): Observable<void> {
    return this.http.delete<void>(this.apiUrl + '/' + id);
  }

  buscar(nombre?: string, ubicacion?: string): Observable<Objeto[]> {
    let params = new HttpParams();
    if (nombre)    params = params.set('nombre', nombre);
    if (ubicacion) params = params.set('ubicacion', ubicacion);
    return this.http.get<Objeto[]>(this.apiUrl + '/buscar', { params });
  }

  filtrar(estado?: string, ubicacion?: string): Observable<Objeto[]> {
    let params = new HttpParams();
    if (estado)    params = params.set('estado', estado);
    if (ubicacion) params = params.set('ubicacion', ubicacion);
    return this.http.get<Objeto[]>(this.apiUrl + '/filtrar', { params });
  }

  marcarDevuelto(id: number, dto: DevolucionRequest): Observable<Objeto> {
    return this.http.patch<Objeto>(this.apiUrl + '/' + id + '/devolucion', dto);
  }
}
