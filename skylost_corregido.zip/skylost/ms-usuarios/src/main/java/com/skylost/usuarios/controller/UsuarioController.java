package com.skylost.usuarios.controller;

import com.skylost.usuarios.dto.*;
import com.skylost.usuarios.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
@CrossOrigin(origins = "*")
@Tag(name = "Usuarios", description = "Gestión de usuarios del sistema Sky Lost")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @PostMapping("/registro")
    @Operation(summary = "Registrar nuevo usuario")
    public ResponseEntity<UsuarioResponseDto> registrar(@RequestBody UsuarioRequestDto dto) {
        return ResponseEntity.ok(service.registrar(dto));
    }

    @PostMapping("/login")
    @Operation(summary = "Iniciar sesión")
    public ResponseEntity<UsuarioResponseDto> login(@RequestBody LoginRequestDto dto) {
        return ResponseEntity.ok(service.login(dto));
    }

    @GetMapping
    @Operation(summary = "Obtener usuario por correo")
    public ResponseEntity<UsuarioResponseDto> obtenerPorCorreo(@RequestParam String correo) {
        return ResponseEntity.ok(service.obtenerPorCorreo(correo));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener usuario por ID")
    public ResponseEntity<UsuarioResponseDto> obtenerPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(service.obtenerPorId(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar usuario")
    public ResponseEntity<UsuarioResponseDto> actualizar(@PathVariable Integer id,
                                                          @RequestBody UsuarioRequestDto dto) {
        return ResponseEntity.ok(service.actualizar(id, dto));
    }
}
