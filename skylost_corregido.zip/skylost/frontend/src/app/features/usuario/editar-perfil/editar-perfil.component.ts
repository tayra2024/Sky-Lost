import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UsuarioService } from '../../../core/services/usuario.service';

@Component({
  selector: 'app-editar-perfil',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './editar-perfil.component.html'
})
export class EditarPerfilComponent implements OnInit {
  form = { nombre: '', apellidos: '', correo: '', celular: '', contrasenia: '' };
  id!: number;
  error = '';
  exito = '';
  loading = false;

  constructor(private auth: AuthService, private usuarioSvc: UsuarioService) {}

  ngOnInit(): void {
    this.id = this.auth.getUserId()!;
    this.usuarioSvc.obtenerPorId(this.id).subscribe({
      next: u => {
        this.form.nombre    = u.nombre;
        this.form.apellidos = u.apellidos;
        this.form.correo    = u.correo;
        this.form.celular   = u.celular;
      },
      error: () => this.error = 'No se pudo cargar el perfil.'
    });
  }

  onSubmit(): void {
    if (!this.form.nombre || !this.form.correo) {
      this.error = 'Nombre y correo son obligatorios.'; return;
    }
    this.loading = true;
    this.usuarioSvc.actualizar(this.id, {
      nombre: this.form.nombre,
      apellidos: this.form.apellidos,
      correo: this.form.correo,
      celular: this.form.celular,
      contrasenia: this.form.contrasenia
    }).subscribe({
      next: u => {
        this.auth.setSession({ ...this.auth.getSession()!, ...u });
        this.exito = 'Perfil actualizado correctamente.';
        this.loading = false;
      },
      error: () => { this.error = 'Error al actualizar.'; this.loading = false; }
    });
  }
}
