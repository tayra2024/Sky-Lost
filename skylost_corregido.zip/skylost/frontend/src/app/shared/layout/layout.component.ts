import { Component } from '@angular/core';
import { Router, RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './layout.component.html'
})
export class LayoutComponent {

  constructor(public auth: AuthService, private router: Router) {}

  get nombreCompleto(): string {
    const s = this.auth.getSession();
    return s ? s.nombre + ' ' + s.apellidos : '';
  }

  get correo(): string {
    return this.auth.getSession()?.correo ?? '';
  }

  logout(): void {
    this.auth.clearSession();
    this.router.navigate(['/login']);
  }
}
