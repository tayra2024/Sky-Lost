package com.skylost.objetos.controller;

import com.skylost.objetos.dto.*;
import com.skylost.objetos.service.ObjetoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/objetos")
@CrossOrigin(origins = "*")
@Tag(name = "Objetos", description = "Gestión de objetos perdidos - Sky Lost")
public class ObjetoController {

    private final ObjetoService service;

    public ObjetoController(ObjetoService service) {
        this.service = service;
    }

    @PostMapping
    @Operation(summary = "Registrar un objeto perdido")
    public ResponseEntity<ObjetoResponseDto> registrar(@RequestBody ObjetoRequestDto dto) {
        return ResponseEntity.ok(service.registrar(dto));
    }

    @GetMapping
    @Operation(summary = "Listar todos los objetos")
    public ResponseEntity<List<ObjetoResponseDto>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener objeto por ID")
    public ResponseEntity<ObjetoResponseDto> obtenerPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(service.obtenerPorId(id));
    }

    @GetMapping("/buscar")
    @Operation(summary = "Buscar objetos por nombre y/o ubicación")
    public ResponseEntity<List<ObjetoResponseDto>> buscar(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String ubicacion) {
        return ResponseEntity.ok(service.buscar(nombre, ubicacion));
    }

    @GetMapping("/filtrar")
    @Operation(summary = "Filtrar objetos por estado y/o ubicación")
    public ResponseEntity<List<ObjetoResponseDto>> filtrar(
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) String ubicacion) {
        return ResponseEntity.ok(service.filtrarPorEstado(estado, ubicacion));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar objeto")
    public ResponseEntity<ObjetoResponseDto> actualizar(
            @PathVariable Integer id, @RequestBody ObjetoRequestDto dto) {
        return ResponseEntity.ok(service.actualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar objeto")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/devolucion")
    @Operation(summary = "Marcar objeto como devuelto")
    public ResponseEntity<ObjetoResponseDto> marcarDevuelto(
            @PathVariable Integer id, @RequestBody DevolucionRequestDto dto) {
        return ResponseEntity.ok(service.marcarDevuelto(id, dto));
    }
}
