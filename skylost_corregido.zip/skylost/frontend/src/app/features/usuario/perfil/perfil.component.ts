import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UsuarioService } from '../../../core/services/usuario.service';
import { Usuario } from '../../../core/models/usuario.model';

@Component({
  selector: 'app-perfil',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './perfil.component.html'
})
export class PerfilComponent implements OnInit {
  usuario: Usuario | null = null;
  error = '';

  constructor(private auth: AuthService, private usuarioSvc: UsuarioService) {}

  ngOnInit(): void {
    const id = this.auth.getUserId();
    if (!id) return;
    this.usuarioSvc.obtenerPorId(id).subscribe({
      next: u => this.usuario = u,
      error: () => this.error = 'No se pudo cargar el perfil.'
    });
  }
}
