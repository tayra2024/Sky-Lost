export interface Usuario {
  id: number;
  correo: string;
  rol: string;
  nombre: string;
  apellidos: string;
  celular: string;
}

export interface LoginRequest {
  correo: string;
  contrasenia: string;
}

export interface RegistroRequest {
  correo: string;
  contrasenia: string;
  nombre: string;
  apellidos: string;
  celular: string;
}
