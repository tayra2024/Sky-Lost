import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-registro',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './registro.component.html'
})
export class RegistroComponent {
  form = { nombre: '', apellidos: '', correo: '', celular: '', contrasenia: '', confirmar: '' };
  error = '';
  exito = '';
  loading = false;

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    if (!this.form.nombre || !this.form.correo || !this.form.contrasenia) {
      this.error = 'Completa los campos obligatorios.'; return;
    }
    if (this.form.contrasenia !== this.form.confirmar) {
      this.error = 'Las contraseñas no coinciden.'; return;
    }
    this.error = '';
    this.loading = true;
    this.auth.registro({
      nombre: this.form.nombre,
      apellidos: this.form.apellidos,
      correo: this.form.correo,
      celular: this.form.celular,
      contrasenia: this.form.contrasenia
    }).subscribe({
      next: () => {
        this.exito = '¡Registro exitoso! Redirigiendo...';
        setTimeout(() => this.router.navigate(['/login']), 1500);
      },
      error: (err) => {
        this.error = err.status === 409 ? 'Ese correo ya está registrado.' : 'Error al registrar. Intenta de nuevo.';
        this.loading = false;
      }
    });
  }
}
