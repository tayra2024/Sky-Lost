package com.skylost.objetos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsObjetosApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsObjetosApplication.class, args);
    }
}
