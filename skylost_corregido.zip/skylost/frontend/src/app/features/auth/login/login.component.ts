import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  correo = '';
  contrasenia = '';
  error = '';
  loading = false;

  constructor(private auth: AuthService, private router: Router) {
    if (this.auth.isLoggedIn()) this.router.navigate(['/objetos']);
  }

  onSubmit(): void {
    if (!this.correo || !this.contrasenia) {
      this.error = 'Por favor completa todos los campos.';
      return;
    }
    this.error = '';
    this.loading = true;
    this.auth.login({ correo: this.correo, contrasenia: this.contrasenia }).subscribe({
      next: () => this.router.navigate(['/objetos']),
      error: () => {
        this.error = 'Correo o contraseña incorrectos.';
        this.loading = false;
      }
    });
  }
}
