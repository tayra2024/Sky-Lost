package com.skylost.objetos.service;

import com.skylost.objetos.config.UsuarioClient;
import com.skylost.objetos.dto.*;
import com.skylost.objetos.model.Objeto;
import com.skylost.objetos.repository.ObjetoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ObjetoService {

    private final ObjetoRepository repo;
    private final UsuarioClient usuarioClient;

    public ObjetoService(ObjetoRepository repo, UsuarioClient usuarioClient) {
        this.repo = repo;
        this.usuarioClient = usuarioClient;
    }

    public ObjetoResponseDto registrar(ObjetoRequestDto dto) {
        Objeto obj = new Objeto();
        obj.setNombre(dto.getNombre());
        obj.setDescripcion(dto.getDescripcion());
        obj.setUbicacion(dto.getUbicacion());
        obj.setEstado(dto.getEstado() != null ? dto.getEstado() : "Perdido");
        obj.setImagen(dto.getImagen());
        obj.setUsuarioId(dto.getUsuarioId());
        return toDto(repo.save(obj));
    }

    public List<ObjetoResponseDto> listar() {
        return repo.findAllByOrderByFechaRegistroDesc()
                .stream().map(this::toDto).collect(Collectors.toList());
    }

    public ObjetoResponseDto obtenerPorId(Integer id) {
        Objeto obj = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Objeto no encontrado"));
        return toDto(obj);
    }

    public List<ObjetoResponseDto> buscar(String nombre, String ubicacion) {
        String n = (nombre != null && !nombre.isBlank()) ? nombre : null;
        String u = (ubicacion != null && !ubicacion.isBlank()) ? ubicacion : null;
        return repo.buscar(n, u).stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<ObjetoResponseDto> filtrarPorEstado(String estado, String ubicacion) {
        String e = (estado != null && !estado.isBlank()) ? estado : null;
        String u = (ubicacion != null && !ubicacion.isBlank()) ? ubicacion : null;
        return repo.filtrarPorEstado(e, u).stream().map(this::toDto).collect(Collectors.toList());
    }

    public ObjetoResponseDto actualizar(Integer id, ObjetoRequestDto dto) {
        Objeto obj = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Objeto no encontrado"));
        obj.setNombre(dto.getNombre());
        obj.setDescripcion(dto.getDescripcion());
        obj.setUbicacion(dto.getUbicacion());
        obj.setEstado(dto.getEstado());
        if (dto.getImagen() != null && !dto.getImagen().isBlank())
            obj.setImagen(dto.getImagen());
        return toDto(repo.save(obj));
    }

    public void eliminar(Integer id) {
        if (!repo.existsById(id))
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Objeto no encontrado");
        repo.deleteById(id);
    }

    public ObjetoResponseDto marcarDevuelto(Integer id, DevolucionRequestDto dto) {
        Objeto obj = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Objeto no encontrado"));
        obj.setEstado("Devuelto");
        obj.setNotaDevolucion(dto.getNota());
        obj.setFechaDevolucion(LocalDateTime.now());
        return toDto(repo.save(obj));
    }

    private ObjetoResponseDto toDto(Objeto obj) {
        ObjetoResponseDto dto = new ObjetoResponseDto();
        dto.setId(obj.getId());
        dto.setNombre(obj.getNombre());
        dto.setDescripcion(obj.getDescripcion());
        dto.setUbicacion(obj.getUbicacion());
        dto.setEstado(obj.getEstado());
        dto.setImagen(obj.getImagen());
        dto.setUsuarioId(obj.getUsuarioId());
        dto.setFechaRegistro(obj.getFechaRegistro());
        dto.setNotaDevolucion(obj.getNotaDevolucion());
        dto.setFechaDevolucion(obj.getFechaDevolucion());
        // Enriquecer con nombre de usuario desde ms-usuarios
        dto.setNombreUsuario(usuarioClient.getNombreUsuario(obj.getUsuarioId()));
        return dto;
    }
}
