package com.skylost.objetos.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "objetos")
public class Objeto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(length = 500)
    private String descripcion;

    @Column(length = 150)
    private String ubicacion;

    @Column(length = 20)
    private String estado = "Perdido";

    @Column(columnDefinition = "LONGTEXT")
    private String imagen;

    @Column(name = "usuario_id")
    private Integer usuarioId;

    @Column(name = "fecha_registro")
    private LocalDateTime fechaRegistro = LocalDateTime.now();

    @Column(name = "nota_devolucion", length = 500)
    private String notaDevolucion;

    @Column(name = "fecha_devolucion")
    private LocalDateTime fechaDevolucion;

    // Campo transient para el nombre del usuario (obtenido del ms-usuarios)
    @Transient
    private String nombreUsuario;

    // Getters & Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) { this.ubicacion = ubicacion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }
    public Integer getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Integer usuarioId) { this.usuarioId = usuarioId; }
    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }
    public String getNotaDevolucion() { return notaDevolucion; }
    public void setNotaDevolucion(String notaDevolucion) { this.notaDevolucion = notaDevolucion; }
    public LocalDateTime getFechaDevolucion() { return fechaDevolucion; }
    public void setFechaDevolucion(LocalDateTime fechaDevolucion) { this.fechaDevolucion = fechaDevolucion; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
}
