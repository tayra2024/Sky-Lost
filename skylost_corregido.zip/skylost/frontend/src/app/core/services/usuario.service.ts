import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario, RegistroRequest } from '../models/usuario.model';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class UsuarioService {

  private apiUrl = environment.apiUrl + '/usuarios';

  constructor(private http: HttpClient) {}

  obtenerPorId(id: number): Observable<Usuario> {
    return this.http.get<Usuario>(this.apiUrl + '/' + id);
  }

  actualizar(id: number, dto: RegistroRequest): Observable<Usuario> {
    return this.http.put<Usuario>(this.apiUrl + '/' + id, dto);
  }
}
