export interface Objeto {
  id: number;
  nombre: string;
  descripcion: string;
  ubicacion: string;
  estado: 'Perdido' | 'Encontrado' | 'Devuelto';
  imagen: string;
  usuarioId: number;
  fechaRegistro: string;
  nombreUsuario: string;
  notaDevolucion?: string;
  fechaDevolucion?: string;
}

export interface ObjetoRequest {
  nombre: string;
  descripcion: string;
  ubicacion: string;
  estado: string;
  imagen?: string;
  usuarioId: number;
}

export interface DevolucionRequest {
  nota: string;
}
