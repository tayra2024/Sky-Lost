import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ObjetoService } from '../../../core/services/objeto.service';
import { AuthService } from '../../../core/services/auth.service';
import { Objeto } from '../../../core/models/objeto.model';

@Component({
  selector: 'app-lista',
  standalone: true,
  imports: [CommonModule, DatePipe, RouterLink],
  templateUrl: './lista.component.html'
})
export class ListaComponent implements OnInit {

  objetos: Objeto[] = [];
  loading = true;
  error = '';
  exito = '';

  get isAdmin(): boolean { return this.auth.isAdmin(); }
  get total(): number { return this.objetos.length; }
  get perdidos(): number { return this.objetos.filter(o => o.estado === 'Perdido').length; }
  get encontrados(): number { return this.objetos.filter(o => o.estado === 'Encontrado').length; }
  get devueltos(): number { return this.objetos.filter(o => o.estado === 'Devuelto').length; }

  constructor(private objetoSvc: ObjetoService, public auth: AuthService) {}

  ngOnInit(): void { this.cargar(); }

  cargar(): void {
    this.loading = true;
    this.objetoSvc.listar().subscribe({
      next: data => { this.objetos = data; this.loading = false; },
      error: () => { this.error = 'Error al cargar objetos.'; this.loading = false; }
    });
  }

  eliminar(id: number): void {
    if (!confirm('¿Eliminar este objeto?')) return;
    this.objetoSvc.eliminar(id).subscribe({
      next: () => {
        this.exito = 'Objeto eliminado.';
        this.cargar();
        setTimeout(() => this.exito = '', 3000);
      },
      error: () => this.error = 'Error al eliminar.'
    });
  }

  exportarExcel(): void {
    import('xlsx').then(XLSX => {
      const data = this.objetos.map(o => ({
        'ID': o.id,
        'Nombre': o.nombre,
        'Descripción': o.descripcion,
        'Ubicación': o.ubicacion,
        'Estado': o.estado,
        'Registrado por': o.nombreUsuario,
        'Fecha': o.fechaRegistro ? new Date(o.fechaRegistro).toLocaleDateString('es-PE') : '',
        'Nota devolución': o.notaDevolucion ?? ''
      }));
      const ws = XLSX.utils.json_to_sheet(data);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Objetos');
      XLSX.writeFile(wb, 'skylost_objetos.xlsx');
    });
  }

  exportarPDF(): void {
    import('jspdf').then(({ jsPDF }) => {
      import('jspdf-autotable').then(() => {
        const doc = new jsPDF({ orientation: 'landscape' });
        doc.setFontSize(16);
        doc.text('Sky Lost – Reporte de Objetos', 14, 15);
        doc.setFontSize(10);
        doc.text(`Generado: ${new Date().toLocaleString('es-PE')}`, 14, 22);
        (doc as any).autoTable({
          startY: 28,
          head: [['ID', 'Nombre', 'Descripción', 'Ubicación', 'Estado', 'Usuario', 'Fecha']],
          body: this.objetos.map(o => [
            o.id,
            o.nombre,
            o.descripcion ?? '',
            o.ubicacion ?? '',
            o.estado,
            o.nombreUsuario ?? '',
            o.fechaRegistro ? new Date(o.fechaRegistro).toLocaleDateString('es-PE') : ''
          ]),
          styles: { fontSize: 8, cellPadding: 3 },
          headStyles: { fillColor: [79, 70, 229], textColor: 255, fontStyle: 'bold' },
          alternateRowStyles: { fillColor: [248, 250, 252] }
        });
        doc.save('skylost_objetos.pdf');
      });
    });
  }
}
