package com.skylost.objetos.dto;

public class DevolucionRequestDto {
    private String nota;
    public String getNota() { return nota; }
    public void setNota(String nota) { this.nota = nota; }
}
