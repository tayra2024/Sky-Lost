import { Component } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ObjetoService } from '../../../core/services/objeto.service';
import { Objeto } from '../../../core/models/objeto.model';

@Component({
  selector: 'app-estado',
  standalone: true,
  imports: [CommonModule, FormsModule, DatePipe],
  templateUrl: './estado.component.html'
})
export class EstadoComponent {
  estado = '';
  ubicacion = '';
  resultados: Objeto[] = [];
  filtrado = false;
  loading = false;

  readonly estados = ['', 'Perdido', 'Encontrado', 'Devuelto'];

  constructor(private objetoSvc: ObjetoService) {}

  filtrar(): void {
    this.loading = true;
    this.filtrado = false;
    this.objetoSvc.filtrar(this.estado, this.ubicacion).subscribe({
      next: data => { this.resultados = data; this.filtrado = true; this.loading = false; },
      error: () => this.loading = false
    });
  }

  limpiar(): void {
    this.estado = '';
    this.ubicacion = '';
    this.resultados = [];
    this.filtrado = false;
  }

  get resumen() {
    return {
      perdidos:    this.resultados.filter(o => o.estado === 'Perdido').length,
      encontrados: this.resultados.filter(o => o.estado === 'Encontrado').length,
      devueltos:   this.resultados.filter(o => o.estado === 'Devuelto').length
    };
  }
}
