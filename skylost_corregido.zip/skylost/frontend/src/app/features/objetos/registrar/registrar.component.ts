import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { ObjetoService } from '../../../core/services/objeto.service';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-registrar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './registrar.component.html'
})
export class RegistrarComponent {
  form = { nombre: '', descripcion: '', ubicacion: '', estado: 'Perdido', imagen: '' };
  error = '';
  exito = '';
  loading = false;
  previewImg = '';

  readonly estados = ['Perdido', 'Encontrado'];

  constructor(private objetoSvc: ObjetoService, private auth: AuthService, private router: Router) {}

  onImagen(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      this.form.imagen = e.target?.result as string;
      this.previewImg  = this.form.imagen;
    };
    reader.readAsDataURL(file);
  }

  onSubmit(): void {
    if (!this.form.nombre || !this.form.ubicacion) {
      this.error = 'Nombre y ubicación son obligatorios.'; return;
    }
    this.error = '';
    this.loading = true;
    this.objetoSvc.registrar({
      nombre: this.form.nombre,
      descripcion: this.form.descripcion,
      ubicacion: this.form.ubicacion,
      estado: this.form.estado,
      imagen: this.form.imagen || undefined,
      usuarioId: this.auth.getUserId()!
    }).subscribe({
      next: () => {
        this.exito = '¡Objeto registrado exitosamente!';
        setTimeout(() => this.router.navigate(['/objetos']), 1200);
      },
      error: () => { this.error = 'Error al registrar el objeto.'; this.loading = false; }
    });
  }
}
