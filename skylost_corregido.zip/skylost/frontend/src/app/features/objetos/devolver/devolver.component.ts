import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ObjetoService } from '../../../core/services/objeto.service';
import { Objeto } from '../../../core/models/objeto.model';

@Component({
  selector: 'app-devolver',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './devolver.component.html'
})
export class DevolverComponent implements OnInit {
  objeto: Objeto | null = null;
  nota = '';
  id!: number;
  error = '';
  exito = '';
  loading = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private objetoSvc: ObjetoService
  ) {}

  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.objetoSvc.obtenerPorId(this.id).subscribe({
      next: obj => this.objeto = obj,
      error: () => this.error = 'No se pudo cargar el objeto.'
    });
  }

  confirmar(): void {
    this.loading = true;
    this.objetoSvc.marcarDevuelto(this.id, { nota: this.nota }).subscribe({
      next: () => {
        this.exito = 'Objeto marcado como devuelto exitosamente.';
        setTimeout(() => this.router.navigate(['/objetos']), 1500);
      },
      error: () => { this.error = 'Error al procesar la devolución.'; this.loading = false; }
    });
  }
}
