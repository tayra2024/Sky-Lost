package com.skylost.usuarios.service;

import com.skylost.usuarios.dto.*;
import com.skylost.usuarios.model.Usuario;
import com.skylost.usuarios.repository.UsuarioRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UsuarioService {

    private final UsuarioRepository repo;

    public UsuarioService(UsuarioRepository repo) {
        this.repo = repo;
    }

    public UsuarioResponseDto registrar(UsuarioRequestDto dto) {
        if (repo.existsByCorreo(dto.getCorreo()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "El correo ya está registrado");
        Usuario u = new Usuario();
        u.setCorreo(dto.getCorreo());
        u.setContrasenia(dto.getContrasenia());
        u.setNombre(dto.getNombre());
        u.setApellidos(dto.getApellidos());
        u.setCelular(dto.getCelular());
        return toDto(repo.save(u));
    }

    public UsuarioResponseDto login(LoginRequestDto dto) {
        return repo.findByCorreoAndContrasenia(dto.getCorreo(), dto.getContrasenia())
                .map(this::toDto)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas"));
    }

    public UsuarioResponseDto obtenerPorCorreo(String correo) {
        return repo.findByCorreo(correo)
                .map(this::toDto)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));
    }

    public UsuarioResponseDto obtenerPorId(Integer id) {
        return repo.findById(id)
                .map(this::toDto)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));
    }

    public UsuarioResponseDto actualizar(Integer id, UsuarioRequestDto dto) {
        Usuario u = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));
        u.setCorreo(dto.getCorreo());
        if (dto.getContrasenia() != null && !dto.getContrasenia().isBlank())
            u.setContrasenia(dto.getContrasenia());
        u.setNombre(dto.getNombre());
        u.setApellidos(dto.getApellidos());
        u.setCelular(dto.getCelular());
        return toDto(repo.save(u));
    }

    private UsuarioResponseDto toDto(Usuario u) {
        UsuarioResponseDto dto = new UsuarioResponseDto();
        dto.setId(u.getId());
        dto.setCorreo(u.getCorreo());
        dto.setRol(u.getRol());
        dto.setNombre(u.getNombre());
        dto.setApellidos(u.getApellidos());
        dto.setCelular(u.getCelular());
        return dto;
    }
}
