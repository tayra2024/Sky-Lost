package com.skylost.usuarios.repository;

import com.skylost.usuarios.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Optional<Usuario> findByCorreo(String correo);
    Optional<Usuario> findByCorreoAndContrasenia(String correo, String contrasenia);
    boolean existsByCorreo(String correo);
}
