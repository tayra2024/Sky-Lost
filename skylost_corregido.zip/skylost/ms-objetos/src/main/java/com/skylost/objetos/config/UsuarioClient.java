package com.skylost.objetos.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Component
public class UsuarioClient {

    private final RestTemplate restTemplate;
    private final String usuariosUrl;

    public UsuarioClient(@Value("${ms.usuarios.url}") String usuariosUrl) {
        this.restTemplate = new RestTemplate();
        this.usuariosUrl = usuariosUrl;
    }

    @SuppressWarnings("unchecked")
    public String getNombreUsuario(Integer usuarioId) {
        if (usuarioId == null) return null;
        try {
            Map<String, Object> response = restTemplate.getForObject(
                    usuariosUrl + "/api/usuarios/" + usuarioId, Map.class);
            if (response != null) {
                String nombre = (String) response.get("nombre");
                String apellidos = (String) response.get("apellidos");
                return nombre + (apellidos != null ? " " + apellidos : "");
            }
        } catch (Exception e) {
            // Si el ms-usuarios no responde, retornamos null sin romper
        }
        return null;
    }
}
