package com.skylost.objetos.repository;

import com.skylost.objetos.model.Objeto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalTime;
import java.util.List;

public interface ObjetoRepository extends JpaRepository<Objeto, Integer> {

    @Query("SELECT o FROM Objeto o WHERE " +
           "(:nombre IS NULL OR LOWER(o.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) AND " +
           "(:ubicacion IS NULL OR LOWER(o.ubicacion) LIKE LOWER(CONCAT('%', :ubicacion, '%'))) " +
           "ORDER BY o.fechaRegistro DESC")
    List<Objeto> buscar(@Param("nombre") String nombre,
                        @Param("ubicacion") String ubicacion);

    @Query("SELECT o FROM Objeto o WHERE " +
           "(:estado IS NULL OR o.estado = :estado) AND " +
           "(:ubicacion IS NULL OR LOWER(o.ubicacion) LIKE LOWER(CONCAT('%', :ubicacion, '%'))) " +
           "ORDER BY o.fechaRegistro DESC")
    List<Objeto> filtrarPorEstado(@Param("estado") String estado,
                                   @Param("ubicacion") String ubicacion);

    List<Objeto> findAllByOrderByFechaRegistroDesc();
}
