import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  {
    path: 'login',
    loadComponent: () => import('./features/auth/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'registro',
    loadComponent: () => import('./features/auth/registro/registro.component').then(m => m.RegistroComponent)
  },
  {
    path: '',
    loadComponent: () => import('./shared/layout/layout.component').then(m => m.LayoutComponent),
    canActivate: [authGuard],
    children: [
      { path: 'objetos', loadComponent: () => import('./features/objetos/lista/lista.component').then(m => m.ListaComponent) },
      { path: 'objetos/registrar', loadComponent: () => import('./features/objetos/registrar/registrar.component').then(m => m.RegistrarComponent) },
      { path: 'objetos/editar/:id', loadComponent: () => import('./features/objetos/editar/editar.component').then(m => m.EditarComponent) },
      { path: 'objetos/buscar', loadComponent: () => import('./features/objetos/buscar/buscar.component').then(m => m.BuscarComponent) },
      { path: 'objetos/estado', loadComponent: () => import('./features/objetos/estado/estado.component').then(m => m.EstadoComponent) },
      { path: 'objetos/devolver/:id', loadComponent: () => import('./features/objetos/devolver/devolver.component').then(m => m.DevolverComponent) },
      { path: 'perfil', loadComponent: () => import('./features/usuario/perfil/perfil.component').then(m => m.PerfilComponent) },
      { path: 'perfil/editar', loadComponent: () => import('./features/usuario/editar-perfil/editar-perfil.component').then(m => m.EditarPerfilComponent) },
      { path: '', redirectTo: 'objetos', pathMatch: 'full' }
    ]
  },
  { path: '**', redirectTo: '/login' }
];
