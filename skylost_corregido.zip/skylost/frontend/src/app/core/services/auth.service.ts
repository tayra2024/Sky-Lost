import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Usuario, LoginRequest, RegistroRequest } from '../models/usuario.model';
import { environment } from '../../../environments/environment';

const SESSION_KEY = 'skylost_user';

@Injectable({ providedIn: 'root' })
export class AuthService {

  private apiUrl = environment.apiUrl + '/usuarios';

  constructor(private http: HttpClient) {}

  login(dto: LoginRequest): Observable<Usuario> {
    return this.http.post<Usuario>(this.apiUrl + '/login', dto).pipe(
      tap(user => this.setSession(user))
    );
  }

  registro(dto: RegistroRequest): Observable<Usuario> {
    return this.http.post<Usuario>(this.apiUrl + '/registro', dto);
  }

  setSession(user: Usuario): void {
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
  }

  getSession(): Usuario | null {
    const s = sessionStorage.getItem(SESSION_KEY);
    return s ? JSON.parse(s) : null;
  }

  clearSession(): void {
    sessionStorage.removeItem(SESSION_KEY);
  }

  isLoggedIn(): boolean { return this.getSession() !== null; }
  isAdmin(): boolean    { return this.getSession()?.rol === 'Admin'; }
  getUserId(): number | null { return this.getSession()?.id ?? null; }
  getNombre(): string   { return this.getSession()?.nombre ?? ''; }
  getIniciales(): string {
    const u = this.getSession();
    if (!u) return '?';
    return ((u.nombre?.[0] ?? '') + (u.apellidos?.[0] ?? '')).toUpperCase();
  }
}
