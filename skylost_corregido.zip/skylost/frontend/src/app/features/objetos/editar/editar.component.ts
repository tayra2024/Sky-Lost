import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ObjetoService } from '../../../core/services/objeto.service';

@Component({
  selector: 'app-editar',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './editar.component.html'
})
export class EditarComponent implements OnInit {
  form = { nombre: '', descripcion: '', ubicacion: '', estado: 'Perdido', imagen: '' };
  id!: number;
  error = '';
  exito = '';
  loading = false;
  previewImg = '';
  readonly estados = ['Perdido', 'Encontrado', 'Devuelto'];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private objetoSvc: ObjetoService
  ) {}

  ngOnInit(): void {
    this.id = Number(this.route.snapshot.paramMap.get('id'));
    this.objetoSvc.obtenerPorId(this.id).subscribe({
      next: obj => {
        this.form = {
          nombre: obj.nombre,
          descripcion: obj.descripcion,
          ubicacion: obj.ubicacion,
          estado: obj.estado,
          imagen: obj.imagen
        };
        this.previewImg = obj.imagen;
      },
      error: () => this.error = 'No se pudo cargar el objeto.'
    });
  }

  onImagen(event: Event): void {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      this.form.imagen = e.target?.result as string;
      this.previewImg  = this.form.imagen;
    };
    reader.readAsDataURL(file);
  }

  onSubmit(): void {
    if (!this.form.nombre || !this.form.ubicacion) {
      this.error = 'Nombre y ubicación son obligatorios.'; return;
    }
    this.error = '';
    this.loading = true;
    this.objetoSvc.actualizar(this.id, {
      nombre: this.form.nombre,
      descripcion: this.form.descripcion,
      ubicacion: this.form.ubicacion,
      estado: this.form.estado,
      imagen: this.form.imagen || undefined,
      usuarioId: 0
    }).subscribe({
      next: () => {
        this.exito = 'Objeto actualizado correctamente.';
        setTimeout(() => this.router.navigate(['/objetos']), 1200);
      },
      error: () => { this.error = 'Error al actualizar.'; this.loading = false; }
    });
  }
}
